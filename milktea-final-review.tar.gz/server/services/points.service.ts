/**
 * Points Service
 * 
 * Handles all points-related operations with transaction support
 * and idempotency protection.
 */

import { eq, and, sql } from "drizzle-orm";
import { getDb } from "../db";
import { member, memberPointsHistory, idempotencyKey } from "../../drizzle/schema";

export type PointsReason = 
  | 'SIGNUP_BONUS' 
  | 'ORDER_EARN' 
  | 'ORDER_REDEEM' 
  | 'ADMIN_ADJUST' 
  | 'EXPIRED'
  | 'REFERRAL_BONUS';

export interface AddPointsParams {
  memberId: number;
  delta: number;
  reason: PointsReason;
  description?: string;
  orderId?: number;
  idempotencyKey?: string;
  expiresAt?: Date;
}

export interface DeductPointsParams {
  memberId: number;
  points: number;
  reason: PointsReason;
  description?: string;
  orderId?: number;
  idempotencyKey?: string;
}

export class PointsService {
  /**
   * Add points to a member's balance (earn)
   * Uses idempotency key to prevent duplicate additions
   */
  async addPoints(params: AddPointsParams): Promise<{ success: boolean; newBalance: number; historyId?: number }> {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { memberId, delta, reason, description, orderId, idempotencyKey: idemKey, expiresAt } = params;

    if (delta <= 0) {
      throw new Error("Delta must be positive for addPoints");
    }

    return await db.transaction(async (tx) => {
      // Check idempotency if key provided
      if (idemKey) {
        const existing = await tx.select()
          .from(idempotencyKey)
          .where(eq(idempotencyKey.key, idemKey))
          .limit(1);
        
        if (existing.length > 0) {
          // Already processed, return cached result
          const result = existing[0].result as { success: boolean; newBalance: number; historyId: number };
          return result;
        }
      }

      // Get current balance with FOR UPDATE lock
      const [currentMember] = await tx.select({
        availablePointsBalance: member.availablePointsBalance,
        totalPointsEarned: member.totalPointsEarned,
      })
        .from(member)
        .where(eq(member.id, memberId))
        .for('update');

      if (!currentMember) {
        throw new Error(`Member ${memberId} not found`);
      }

      const newBalance = currentMember.availablePointsBalance + delta;
      const newTotalEarned = currentMember.totalPointsEarned + delta;

      // Update member balance
      await tx.update(member)
        .set({
          availablePointsBalance: newBalance,
          totalPointsEarned: newTotalEarned,
          updatedAt: new Date(),
        })
        .where(eq(member.id, memberId));

      // Insert history record
      const [history] = await tx.insert(memberPointsHistory)
        .values({
          memberId,
          delta,
          balanceAfter: newBalance,
          reason,
          description,
          orderId,
          idempotencyKey: idemKey,
          expiresAt,
        })
        .returning({ id: memberPointsHistory.id });

      const result = { success: true, newBalance, historyId: history.id };

      // Store idempotency result if key provided
      if (idemKey) {
        await tx.insert(idempotencyKey)
          .values({
            key: idemKey,
            result,
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
          });
      }

      return result;
    });
  }

  /**
   * Deduct points from a member's balance (redeem)
   * Validates sufficient balance before deduction
   */
  async deductPoints(params: DeductPointsParams): Promise<{ success: boolean; newBalance: number; historyId?: number }> {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { memberId, points, reason, description, orderId, idempotencyKey: idemKey } = params;

    if (points <= 0) {
      throw new Error("Points must be positive for deductPoints");
    }

    return await db.transaction(async (tx) => {
      // Check idempotency if key provided
      if (idemKey) {
        const existing = await tx.select()
          .from(idempotencyKey)
          .where(eq(idempotencyKey.key, idemKey))
          .limit(1);
        
        if (existing.length > 0) {
          const result = existing[0].result as { success: boolean; newBalance: number; historyId: number };
          return result;
        }
      }

      // Get current balance with FOR UPDATE lock
      const [currentMember] = await tx.select({
        availablePointsBalance: member.availablePointsBalance,
      })
        .from(member)
        .where(eq(member.id, memberId))
        .for('update');

      if (!currentMember) {
        throw new Error(`Member ${memberId} not found`);
      }

      // Validate sufficient balance
      if (currentMember.availablePointsBalance < points) {
        throw new Error(`Insufficient points balance. Available: ${currentMember.availablePointsBalance}, Required: ${points}`);
      }

      const newBalance = currentMember.availablePointsBalance - points;

      // Update member balance
      await tx.update(member)
        .set({
          availablePointsBalance: newBalance,
          updatedAt: new Date(),
        })
        .where(eq(member.id, memberId));

      // Insert history record (negative delta for deduction)
      const [history] = await tx.insert(memberPointsHistory)
        .values({
          memberId,
          delta: -points,
          balanceAfter: newBalance,
          reason,
          description,
          orderId,
          idempotencyKey: idemKey,
        })
        .returning({ id: memberPointsHistory.id });

      const result = { success: true, newBalance, historyId: history.id };

      // Store idempotency result if key provided
      if (idemKey) {
        await tx.insert(idempotencyKey)
          .values({
            key: idemKey,
            result,
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
          });
      }

      return result;
    });
  }

  /**
   * Issue signup bonus with idempotency protection
   * Uses phone as idempotency key to prevent duplicate bonuses
   */
  async issueSignupBonus(memberId: number, phone: string, bonusPoints: number = 100): Promise<{ success: boolean; newBalance: number }> {
    const idemKey = `signup_bonus:${phone}`;
    
    return await this.addPoints({
      memberId,
      delta: bonusPoints,
      reason: 'SIGNUP_BONUS',
      description: `Welcome bonus for new member registration`,
      idempotencyKey: idemKey,
    });
  }

  /**
   * Calculate points to earn from an order
   * Special price items are excluded from points calculation
   */
  calculateOrderPoints(orderItems: Array<{ totalPrice: number; isSpecialPrice: boolean }>, multiplier: number = 1): number {
    const eligibleAmount = orderItems
      .filter(item => !item.isSpecialPrice)
      .reduce((sum, item) => sum + Number(item.totalPrice), 0);
    
    // 1 point per 10 RUB spent (configurable)
    const basePoints = Math.floor(eligibleAmount / 10);
    return Math.floor(basePoints * multiplier);
  }

  /**
   * Get member's points balance
   */
  async getBalance(memberId: number): Promise<{ available: number; totalEarned: number }> {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const [result] = await db.select({
      available: member.availablePointsBalance,
      totalEarned: member.totalPointsEarned,
    })
      .from(member)
      .where(eq(member.id, memberId));

    if (!result) {
      throw new Error(`Member ${memberId} not found`);
    }

    return result;
  }

  /**
   * Get points history for a member
   */
  async getHistory(memberId: number, limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db.select()
      .from(memberPointsHistory)
      .where(eq(memberPointsHistory.memberId, memberId))
      .orderBy(sql`${memberPointsHistory.createdAt} DESC`)
      .limit(limit)
      .offset(offset);
  }
}

export const pointsService = new PointsService();
